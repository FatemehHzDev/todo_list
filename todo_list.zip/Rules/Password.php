<?php

namespace Rules;

class Password
{

    public static function defaults()
    {
    }
}
